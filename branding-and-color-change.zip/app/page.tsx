"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { BottomNav } from "@/components/bottom-nav"
import { HomeQuickCard } from "@/components/home-quick-card"
import { ShoppingCartIcon, BotIcon, BellIcon } from "@/components/icons"
import Link from "next/link"
import { SubTrackLogo } from "@/components/subtrack-logo"

export default function Home() {
  const { isAuthenticated } = useAuth()
  const router = useRouter()
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    } else {
      setShowContent(true)
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] pb-28">
      {/* Header with Logo */}
      <div className="px-6 py-8 text-center border-b border-[#2D2D2D]">
        <div className={`transition-opacity duration-500 ${showContent ? "opacity-100" : "opacity-0"}`}>
          {/* Logo */}
          <SubTrackLogo size={64} className="mx-auto mb-4" />

          {/* App Name */}
          <h1 className="text-4xl font-bold text-[#F5F5F7] tracking-tight">SubTrack</h1>

          {/* Tagline */}
          <p className="text-[#9CA3AF] text-sm mt-2">Manage your subscriptions easily.</p>
        </div>
      </div>

      {/* Quick Cards Section */}
      <div className="px-6 py-6 space-y-4">
        {/* Top Row - Two Cards */}
        <div className="grid grid-cols-2 gap-4">
          <HomeQuickCard href="/subscriptions" icon={<ShoppingCartIcon className="w-8 h-8" />} title="Subscriptions" />
          <HomeQuickCard href="/ai-assistance" icon={<BotIcon className="w-8 h-8" />} title="AI Assistance" />
        </div>

        {/* Full Width Card */}
        <HomeQuickCard href="/notifications" icon={<BellIcon className="w-8 h-8" />} title="Notifications" fullWidth />
      </div>

      {/* Settings Link at bottom (before nav) */}
      <div className="px-6 py-4">
        <Link href="/settings">
          <button className="w-full py-3 bg-[#161616] text-[#F5F5F7] rounded-[20px] font-semibold active:scale-95 transition-transform">
            Settings
          </button>
        </Link>
      </div>

      <BottomNav />
    </div>
  )
}
