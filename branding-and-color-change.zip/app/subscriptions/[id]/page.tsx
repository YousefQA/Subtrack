"use client"

import { useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { ArrowLeftIcon } from "@/components/icons"
import { mockSubscriptions } from "@/lib/mock-data"
import { getActiveDuration, getDaysRemaining } from "@/lib/helpers"
import { BottomNav } from "@/components/bottom-nav"

export default function SubscriptionDetailPage() {
  const { isAuthenticated } = useAuth()
  const router = useRouter()
  const params = useParams()
  const id = params.id as string

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  const subscription = mockSubscriptions.find((sub) => sub.id === id)

  if (!isAuthenticated) {
    return null
  }

  if (!subscription) {
    return (
      <div className="min-h-screen bg-[#0B0B0B] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-[#F5F5F7] mb-4">Subscription not found</h1>
          <button
            onClick={() => router.push("/subscriptions")}
            className="px-6 py-3 bg-[#3b82f6] text-white rounded-[12px] font-semibold"
          >
            Back to subscriptions
          </button>
        </div>
      </div>
    )
  }

  const daysActive = getActiveDuration(subscription.startedAt)
  const daysRemaining = getDaysRemaining(subscription.endsAt)

  return (
    <div className="min-h-screen bg-[#0B0B0B] pb-28">
      {/* Header with back button */}
      <div className="px-6 py-6 border-b border-[#2D2D2D] flex items-center gap-4">
        <button onClick={() => router.back()} className="p-2 hover:bg-[#181818] rounded-lg transition-colors">
          <ArrowLeftIcon className="w-6 h-6 text-[#F5F5F7]" />
        </button>
        <h1 className="text-2xl font-bold text-[#F5F5F7]">Subscription Details</h1>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Subscription name */}
        <div>
          <p className="text-[#9CA3AF] text-sm mb-2">Subscription</p>
          <h2 className="text-3xl font-bold text-[#F5F5F7]">{subscription.name}</h2>
        </div>

        {/* Details grid */}
        <div className="space-y-3">
          <div className="bg-[#181818] rounded-[20px] p-6 border border-[#2D2D2D]">
            <p className="text-[#9CA3AF] text-sm mb-2">Active for</p>
            <p className="text-[#F5F5F7] text-3xl font-bold">{daysActive} days</p>
          </div>

          <div className="bg-[#181818] rounded-[20px] p-6 border border-[#2D2D2D]">
            <p className="text-[#9CA3AF] text-sm mb-2">Started on</p>
            <p className="text-[#F5F5F7] text-lg">{subscription.startedAt.toLocaleDateString()}</p>
          </div>

          <div className="bg-[#181818] rounded-[20px] p-6 border border-[#2D2D2D]">
            <p className="text-[#9CA3AF] text-sm mb-2">Ends on</p>
            <p className="text-[#F5F5F7] text-lg">{subscription.endsAt.toLocaleDateString()}</p>
          </div>

          <div
            className={`rounded-[20px] p-6 border ${
              daysRemaining <= 3 ? "bg-[#3b82f6]/10 border-[#3b82f6]" : "bg-[#181818] border-[#2D2D2D]"
            }`}
          >
            <p className="text-[#9CA3AF] text-sm mb-2">Days remaining</p>
            <p className={`text-3xl font-bold ${daysRemaining <= 3 ? "text-[#3b82f6]" : "text-[#F5F5F7]"}`}>
              {daysRemaining} days
            </p>
          </div>
        </div>

        {/* Back button */}
        <button
          onClick={() => router.push("/subscriptions")}
          className="w-full py-4 bg-[#161616] text-[#F5F5F7] rounded-[12px] font-semibold active:scale-95 transition-transform"
        >
          Back to subscriptions
        </button>
      </div>

      <BottomNav />
    </div>
  )
}
