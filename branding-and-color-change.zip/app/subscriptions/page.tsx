"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { PlusIcon } from "@/components/icons"
import { BottomNav } from "@/components/bottom-nav"
import { AddSubscriptionModal } from "@/components/add-subscription-modal"
import { SubscriptionCard } from "@/components/subscription-card"
import { mockSubscriptions } from "@/lib/mock-data"
import { getDaysRemaining, getNextEndingSubscription } from "@/lib/helpers"
import type { Subscription } from "@/lib/mock-data"
import { SubTrackLogo } from "@/components/subtrack-logo"

export default function SubscriptionsPage() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>(mockSubscriptions)
  const [showAddModal, setShowAddModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState<"name" | "ending">("name")
  const { isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  const handleAddSubscription = (name: string, startDate: string, endDate: string) => {
    const newSub: Subscription = {
      id: Date.now().toString(),
      name,
      startedAt: new Date(startDate),
      endsAt: new Date(endDate),
    }
    setSubscriptions([...subscriptions, newSub])
    setShowAddModal(false)
  }

  const handleSelectSubscription = (subscription: Subscription) => {
    router.push(`/subscriptions/${subscription.id}`)
  }

  const filteredSubscriptions = subscriptions
    .filter((sub) => sub.name.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === "name") {
        return a.name.localeCompare(b.name)
      } else {
        return getDaysRemaining(a.endsAt) - getDaysRemaining(b.endsAt)
      }
    })

  const nextEnding = getNextEndingSubscription(subscriptions)
  const nextEndingDays = nextEnding ? getDaysRemaining(nextEnding.endsAt) : 0

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] pb-28">
      {/* Header */}
      <div className="px-6 py-6 border-b border-[#2D2D2D]">
        <h1 className="text-2xl font-bold text-[#F5F5F7]">Your Subscriptions</h1>
      </div>

      {subscriptions.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
          {/* Empty State Logo */}
          <SubTrackLogo size={80} className="mb-6 opacity-50" />

          <h2 className="text-xl font-bold text-[#F5F5F7] mb-2">No subscriptions yet</h2>
          <p className="text-[#9CA3AF] mb-6 max-w-xs">When you add subscriptions, they'll show up here.</p>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#3b82f6] text-white rounded-[12px] font-semibold active:scale-95 transition-transform"
          >
            <PlusIcon className="w-5 h-5" />
            Add subscription
          </button>
        </div>
      ) : (
        <div className="px-6 py-6 space-y-4">
          {/* Summary Strip */}
          <div className="bg-[#181818] rounded-[20px] p-4 border border-[#2D2D2D]">
            <p className="text-sm text-[#F5F5F7]">
              You own <span className="font-bold text-[#3b82f6]">{subscriptions.length}</span> subscriptions • Next
              renewal: <span className="font-bold">{nextEnding?.name}</span> in{" "}
              <span className="font-bold text-[#3b82f6]">{nextEndingDays}</span> days
            </p>
          </div>

          {/* Search and Sort */}
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Search subscriptions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#181818] rounded-[12px] px-4 py-3 text-[#F5F5F7] placeholder-[#6B7280] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
            />

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as "name" | "ending")}
              className="w-full bg-[#181818] rounded-[12px] px-4 py-3 text-[#F5F5F7] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
            >
              <option value="name">Sort by Name</option>
              <option value="ending">Soonest to end</option>
            </select>
          </div>

          {/* Subscriptions List */}
          <div className="space-y-3">
            {filteredSubscriptions.map((sub) => (
              <SubscriptionCard key={sub.id} subscription={sub} onClick={() => handleSelectSubscription(sub)} />
            ))}
          </div>
        </div>
      )}

      {subscriptions.length > 0 && (
        <div className="px-6 py-4">
          <button
            onClick={() => setShowAddModal(true)}
            className="w-full flex items-center justify-center gap-2 py-3 bg-[#161616] text-[#F5F5F7] rounded-[12px] font-semibold active:scale-95 transition-transform"
          >
            <PlusIcon className="w-5 h-5" />
            Add subscription
          </button>
        </div>
      )}

      <AddSubscriptionModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={handleAddSubscription}
      />

      <BottomNav />
    </div>
  )
}
