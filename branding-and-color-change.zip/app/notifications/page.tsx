"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { BottomNav } from "@/components/bottom-nav"
import { NotificationItem } from "@/components/notification-item"
import { mockSubscriptions, mockNotifications } from "@/lib/mock-data"
import type { Notification } from "@/lib/mock-data"

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications)
  const [filterBy, setFilterBy] = useState<"all" | "upcoming" | "overdue" | "read">("all")
  const { isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  const filterChips = [
    { label: "All", value: "all" as const },
    { label: "Upcoming", value: "upcoming" as const },
    { label: "Overdue", value: "overdue" as const },
    { label: "Read", value: "read" as const },
  ]

  const filteredNotifications = notifications.filter((notif) => {
    if (filterBy === "all") return true
    return notif.type === filterBy
  })

  const handleMarkRead = (id: string) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: !n.read } : n)))
  }

  const handleSnooze = (id: string) => {
    const snoozedDate = new Date()
    snoozedDate.setDate(snoozedDate.getDate() + 1)
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, snoozedUntil: snoozedDate } : n)))
  }

  const handleAddTestReminder = () => {
    const randomSub = mockSubscriptions[Math.floor(Math.random() * mockSubscriptions.length)]
    const newNotif: Notification = {
      id: Date.now().toString(),
      type: "upcoming",
      title: `${randomSub.name} renews soon`,
      subtitle: "Renews in 5 days",
      subscriptionId: randomSub.id,
      read: false,
    }
    setNotifications([...notifications, newNotif])
  }

  const getSubscriptionName = (subscriptionId: string): string => {
    return mockSubscriptions.find((s) => s.id === subscriptionId)?.name || "Unknown Subscription"
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] pb-28">
      {/* Header */}
      <div className="px-6 py-6 border-b border-[#2D2D2D]">
        <h1 className="text-2xl font-bold text-[#F5F5F7]">Notifications</h1>
      </div>

      <div className="px-6 py-6 space-y-6">
        {mockSubscriptions.length === 0 ? (
          // No subscriptions state
          <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
            <svg
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
              width="64"
              height="64"
              className="mb-4 opacity-50"
              fill="none"
              stroke="#6B7280"
              strokeWidth="1.5"
            >
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" />
            </svg>
            <h2 className="text-xl font-bold text-[#F5F5F7] mb-2">No Owned Subscriptions</h2>
            <p className="text-[#9CA3AF] max-w-xs">
              Once you add subscriptions, you'll start receiving reminders here.
            </p>
          </div>
        ) : (
          <>
            {/* Summary text */}
            <p className="text-sm text-[#9CA3AF]">
              You currently own <span className="font-bold text-[#F5F5F7]">{mockSubscriptions.length}</span>{" "}
              subscriptions. Here are your upcoming and overdue reminders.
            </p>

            {/* Filter Chips */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              {filterChips.map((chip) => (
                <button
                  key={chip.value}
                  onClick={() => setFilterBy(chip.value)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-colors ${
                    filterBy === chip.value
                      ? "bg-[#3b82f6] text-white"
                      : "bg-[#181818] text-[#9CA3AF] hover:text-[#F5F5F7]"
                  }`}
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Notifications List */}
            {filteredNotifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
                <h3 className="text-[#F5F5F7] font-semibold mb-1">No notifications found</h3>
                <p className="text-[#9CA3AF] text-sm">for this category.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredNotifications.map((notif) => (
                  <NotificationItem
                    key={notif.id}
                    notification={notif}
                    subscriptionName={getSubscriptionName(notif.subscriptionId)}
                    onMarkRead={() => handleMarkRead(notif.id)}
                    onSnooze={() => handleSnooze(notif.id)}
                  />
                ))}
              </div>
            )}

            {/* Test Reminder Button */}
            <button
              onClick={handleAddTestReminder}
              className="w-full py-3 bg-[#161616] text-[#F5F5F7] rounded-[12px] font-semibold active:scale-95 transition-transform mt-4"
            >
              Create test reminder
            </button>
          </>
        )}
      </div>

      <BottomNav />
    </div>
  )
}
