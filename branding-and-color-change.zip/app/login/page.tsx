"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import Link from "next/link"
import { SubTrackLogo } from "@/components/subtrack-logo"

export default function LoginPage() {
  const [login, setLogin] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()
  const { login: authLogin } = useAuth()

  const handleContinue = () => {
    authLogin()
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] flex flex-col items-center justify-center px-6 py-8">
      {/* Logo */}
      <SubTrackLogo size={64} className="mb-6" />

      {/* Heading */}
      <h1 className="text-3xl font-bold text-[#F5F5F7] mb-8 text-center">SubTrack</h1>

      {/* Form */}
      <div className="w-full max-w-sm space-y-4">
        <div>
          <label className="block text-sm text-[#F5F5F7] mb-2">Login</label>
          <input
            type="text"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
            className="w-full bg-[#181818] rounded-[12px] px-4 py-3 text-[#F5F5F7] placeholder-[#6B7280] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
            placeholder="Enter your login"
          />
        </div>

        <div>
          <label className="block text-sm text-[#F5F5F7] mb-2">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-[#181818] rounded-[12px] px-4 py-3 text-[#F5F5F7] placeholder-[#6B7280] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
            placeholder="Enter your password"
          />
        </div>

        <button
          onClick={handleContinue}
          className="w-full py-3 bg-[#3b82f6] text-white rounded-[20px] font-semibold mt-6 active:scale-95 transition-transform"
        >
          Continue
        </button>
      </div>

      {/* Link to Signup */}
      <div className="mt-6 text-center">
        <span className="text-[#9CA3AF] text-sm">Don&apos;t have an account? </span>
        <Link href="/signup" className="text-[#3b82f6] font-semibold hover:underline">
          Create an account
        </Link>
      </div>

      {/* Caption */}
      <p className="text-[#6B7280] text-xs mt-8 text-center max-w-xs">Prototype only — no real authentication.</p>
    </div>
  )
}
