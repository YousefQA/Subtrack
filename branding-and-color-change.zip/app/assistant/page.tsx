"use client"

import { useState } from "react"
import { BottomNav } from "@/components/bottom-nav"
import { Brain, Star, Award } from "lucide-react"
import { subscriptions } from "@/lib/mock-data"
import { getDaysRemaining, getNextEndingSubscription } from "@/lib/helpers"

export default function AssistantPage() {
  const [dismissed, setDismissed] = useState(false)
  const [optimizeOpen, setOptimizeOpen] = useState(false)

  const nextEnding = getNextEndingSubscription(subscriptions)
  const daysUntilNext = nextEnding ? getDaysRemaining(nextEnding.endsAt) : 0
  const totalSubs = subscriptions.length

  if (dismissed) {
    return (
      <div className="min-h-screen bg-[#0B0B0B] text-white flex items-center justify-center pb-20">
        <button
          onClick={() => setDismissed(false)}
          className="px-6 py-3 bg-[#3b82f6] text-white rounded-lg font-semibold active:scale-95 transition-transform"
        >
          Show Recommendations
        </button>
        <BottomNav />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-white pb-28">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-4">
        <div className="flex items-center gap-3">
          <Brain size={24} className="text-white" />
          <h1 className="text-2xl font-bold">Smart Assistant</h1>
        </div>
        <div className="w-3 h-3 bg-[#3b82f6] rounded-full" />
      </div>

      {/* Plan recommendations */}
      <div className="px-4 mt-6">
        <p className="text-[#9CA3AF] text-sm mb-3">Plan recommendations</p>
        <div className="bg-[#181818] rounded-[20px] p-4 flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1">
            <div className="w-8 h-8 bg-orange-500/20 rounded-lg flex items-center justify-center">
              <Award size={18} className="text-orange-400" />
            </div>
            <div>
              <p className="text-white font-semibold text-sm">Switch to 120 points</p>
              <p className="text-[#6B7280] text-xs mt-1">You console:muirqng</p>
            </div>
          </div>
          <Star size={20} className="text-[#3b82f6] fill-[#3b82f6]" />
        </div>
      </div>

      {/* Achievements */}
      <div className="px-4 mt-6">
        <p className="text-[#9CA3AF] text-sm mb-3">Achievements</p>
        <div className="bg-[#181818] rounded-[20px] p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <p className="text-white font-semibold text-sm">Cancel 1un</p>
              <p className="text-[#6B7280] text-xs mt-1">Uitted sulbseri...</p>
            </div>
            <div className="flex items-center gap-2 ml-4">
              <span className="text-white font-semibold">+ 5</span>
              <div className="relative">
                <div className="w-5 h-5 bg-[#3b82f6] rounded-full flex items-center justify-center">
                  <span className="text-white text-[9px] font-bold">n0</span>
                </div>
              </div>
            </div>
          </div>
          <p className="text-[#6B7280] text-xs">Earn 37 pts</p>
        </div>
      </div>

      {/* Summary row */}
      <div className="px-4 mt-6 pb-4 border-b border-[#2D2D2D]">
        <p className="text-[#6B7280] text-xs leading-relaxed">
          Total subscriptions: {totalSubs} • Next to end: {nextEnding?.name} in {daysUntilNext} days
        </p>
      </div>

      {/* Footer buttons */}
      <div className="flex gap-3 px-4 mt-8">
        <button
          onClick={() => setOptimizeOpen(!optimizeOpen)}
          className="flex-1 py-3 bg-[#161616] text-white rounded-lg font-semibold active:scale-95 transition-transform"
        >
          Optimize
        </button>
        <button
          onClick={() => setDismissed(true)}
          className="flex-1 py-3 bg-[#3b82f6] text-white rounded-lg font-semibold active:scale-95 transition-transform"
        >
          Dismiss
        </button>
      </div>

      {optimizeOpen && (
        <div className="px-4 mt-4 p-4 bg-[#181818] rounded-[20px] border border-[#3b82f6]">
          <p className="text-white font-semibold text-sm mb-2">Optimization suggestion</p>
          <p className="text-[#9CA3AF] text-xs">
            Consider canceling subscriptions ending in the next 3 days to save money.
          </p>
        </div>
      )}

      <BottomNav />
    </div>
  )
}
