"use client"

import { useState } from "react"
import { BottomNav } from "@/components/bottom-nav"
import { Building2 } from "lucide-react"
import { subscriptions } from "@/lib/mock-data"
import { getAverageMonthlySpend } from "@/lib/helpers"
import { useToast } from "@/hooks/use-toast"

export default function BillingPage() {
  const [exportFormat, setExportFormat] = useState<string | null>(null)
  const { toast } = useToast()

  const avgSpend = getAverageMonthlySpend(subscriptions)

  const handleExport = (format: string) => {
    const data = subscriptions
      .map((s) => `${s.name},${s.monthlyPrice},${s.startedAt.toISOString()},${s.endsAt.toISOString()}`)
      .join("\n")

    const blob = new Blob([`Name,Price,Started,Ends\n${data}`], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `subscriptions.${format}`
    a.click()
    URL.revokeObjectURL(url)

    setExportFormat(format)
    setTimeout(() => setExportFormat(null), 1000)
  }

  const handleDone = () => {
    toast({
      title: "Saved",
      description: "Billing configuration saved successfully.",
    })
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-white pb-28">
      {/* Header */}
      <div className="px-4 py-4">
        <p className="text-[#9CA3AF] text-xs uppercase tracking-wide mb-2">Billing</p>
        <h1 className="text-2xl font-bold">Billing management</h1>
      </div>

      {/* Linked accounts */}
      <div className="px-4 mt-6">
        <p className="text-[#9CA3AF] text-sm mb-3">Linked accounts</p>
        <div className="space-y-2">
          <div className="bg-[#181818] rounded-[20px] p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xs">
              IP
            </div>
            <div className="flex-1">
              <p className="text-white font-semibold text-sm">PayPal</p>
              <p className="text-[#9CA3AF] text-xs mt-0.5">syscet</p>
            </div>
          </div>

          <div className="bg-[#181818] rounded-[20px] p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-[#2D2D2D] rounded-lg flex items-center justify-center">
              <Building2 size={20} className="text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white font-semibold text-sm">Bank</p>
              <p className="text-[#9CA3AF] text-xs mt-0.5">Syscet1</p>
            </div>
          </div>
        </div>
      </div>

      {/* Export options */}
      <div className="px-4 mt-6">
        <p className="text-[#9CA3AF] text-sm mb-3">Export options</p>
        <div className="flex gap-3">
          <button
            onClick={() => handleExport("csv")}
            className={`flex-1 py-3 rounded-lg font-semibold transition-all active:scale-95 ${
              exportFormat === "csv" ? "bg-[#3b82f6] text-white" : "bg-[#161616] text-white border border-[#2D2D2D]"
            }`}
          >
            CSV
          </button>
          <button
            onClick={() => handleExport("pdf")}
            className={`flex-1 py-3 rounded-lg font-semibold transition-all active:scale-95 ${
              exportFormat === "pdf" ? "bg-[#3b82f6] text-white" : "bg-[#161616] text-white border border-[#2D2D2D]"
            }`}
          >
            PDF
          </button>
        </div>
      </div>

      {/* Info line */}
      <div className="px-4 mt-6 pb-4">
        <p className="text-[#6B7280] text-xs">Avg monthly spend: ${avgSpend.toFixed(2)}</p>
      </div>

      {/* Footer buttons */}
      <div className="flex gap-3 px-4 mt-8">
        <button className="flex-1 py-3 bg-[#161616] text-white rounded-lg font-semibold active:scale-95 transition-transform">
          Cancel
        </button>
        <button
          onClick={handleDone}
          className="flex-1 py-3 bg-white text-black rounded-lg font-semibold active:scale-95 transition-transform"
        >
          Done
        </button>
      </div>

      <BottomNav />
    </div>
  )
}
