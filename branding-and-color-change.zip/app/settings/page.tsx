"use client"

import { useState } from "react"
import { EyeIcon } from "@/components/icons"
import { BottomNav } from "@/components/bottom-nav"
import { LogoDialog } from "@/components/logo-dialog"

export default function SettingsPage() {
  const [theme, setTheme] = useState<"dark" | "light">("dark")
  const [billingReminders, setBillingReminders] = useState(true)
  const [trialAlerts, setTrialAlerts] = useState(true)
  const [currency, setCurrency] = useState<"USD" | "EUR" | "AED">("USD")
  const [showLogoDialog, setShowLogoDialog] = useState(false)

  const handleReset = () => {
    setTheme("dark")
    setBillingReminders(true)
    setTrialAlerts(true)
    setCurrency("USD")
  }

  const handleExportCSV = () => {
    const data = "Name,Start Date,End Date\n"
    const blob = new Blob([data], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "subscriptions.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleExportPDF = () => {
    const data = "%PDF-1.4\n%Subscriptions Export"
    const blob = new Blob([data], { type: "application/pdf" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "subscriptions.pdf"
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] pb-28">
      {/* Header */}
      <div className="px-6 py-6 border-b border-[#2D2D2D]">
        <h1 className="text-2xl font-bold text-[#F5F5F7]">Settings</h1>
      </div>

      {/* Settings Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Appearance */}
        <div>
          <h3 className="text-[#9CA3AF] text-sm font-semibold mb-3">Appearance</h3>
          <div className="bg-[#181818] rounded-[20px] p-4 flex gap-2">
            <button
              onClick={() => setTheme("dark")}
              className={`flex-1 py-2 px-4 rounded-[8px] font-semibold transition-colors ${
                theme === "dark" ? "bg-[#3b82f6] text-white" : "bg-[#161616] text-[#9CA3AF]"
              }`}
            >
              Dark
            </button>
            <button
              onClick={() => setTheme("light")}
              className={`flex-1 py-2 px-4 rounded-[8px] font-semibold transition-colors ${
                theme === "light" ? "bg-white text-black" : "bg-[#161616] text-[#9CA3AF]"
              }`}
            >
              Light
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div>
          <h3 className="text-[#9CA3AF] text-sm font-semibold mb-3">Notifications</h3>
          <div className="space-y-2">
            <div className="bg-[#181818] rounded-[20px] p-4 flex items-center justify-between">
              <span className="text-[#F5F5F7] font-medium">Billing reminders</span>
              <button
                onClick={() => setBillingReminders(!billingReminders)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  billingReminders ? "bg-[#3b82f6]" : "bg-[#2D2D2D]"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    billingReminders ? "translate-x-6" : "translate-x-0.5"
                  }`}
                />
              </button>
            </div>
            <div className="bg-[#181818] rounded-[20px] p-4 flex items-center justify-between">
              <span className="text-[#F5F5F7] font-medium">Trial ending alerts</span>
              <button
                onClick={() => setTrialAlerts(!trialAlerts)}
                className={`w-12 h-6 rounded-full transition-colors ${trialAlerts ? "bg-[#3b82f6]" : "bg-[#2D2D2D]"}`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    trialAlerts ? "translate-x-6" : "translate-x-0.5"
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Currency */}
        <div>
          <h3 className="text-[#9CA3AF] text-sm font-semibold mb-3">Currency</h3>
          <div className="bg-[#181818] rounded-[20px] p-4">
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as "USD" | "EUR" | "AED")}
              className="w-full bg-[#161616] rounded-[8px] px-4 py-2 text-[#F5F5F7] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="AED">AED (د.إ)</option>
            </select>
          </div>
        </div>

        {/* Data Export */}
        <div>
          <h3 className="text-[#9CA3AF] text-sm font-semibold mb-3">Data</h3>
          <div className="space-y-2">
            <button
              onClick={handleExportCSV}
              className="w-full bg-[#181818] rounded-[20px] p-4 text-left text-[#F5F5F7] font-semibold hover:bg-[#1F1F1F] transition-colors active:scale-95"
            >
              Export CSV
            </button>
            <button
              onClick={handleExportPDF}
              className="w-full bg-[#181818] rounded-[20px] p-4 text-left text-[#F5F5F7] font-semibold hover:bg-[#1F1F1F] transition-colors active:scale-95"
            >
              Export PDF
            </button>
          </div>
        </div>

        {/* About */}
        <div>
          <h3 className="text-[#9CA3AF] text-sm font-semibold mb-3">About</h3>
          <div className="bg-[#181818] rounded-[20px] p-4 flex items-center justify-between">
            <span className="text-[#F5F5F7]">
              Version: <span className="font-semibold">v1.0</span>
              <span className="text-[#9CA3AF] text-sm ml-1">(Front-end only)</span>
            </span>
          </div>
          <button
            onClick={() => setShowLogoDialog(true)}
            className="w-full mt-2 bg-[#181818] rounded-[20px] p-4 flex items-center gap-2 text-[#F5F5F7] font-semibold hover:bg-[#1F1F1F] transition-colors active:scale-95"
          >
            <EyeIcon className="w-5 h-5" />
            View Logo
          </button>
        </div>

        {/* Reset */}
        <button
          onClick={handleReset}
          className="w-full py-3 bg-[#161616] text-[#3b82f6] rounded-[12px] font-semibold border border-[#2D2D2D] hover:bg-[#1F1F1F] transition-colors mt-8 active:scale-95"
        >
          Reset to defaults
        </button>
      </div>

      <LogoDialog isOpen={showLogoDialog} onClose={() => setShowLogoDialog(false)} />

      <BottomNav />
    </div>
  )
}
