"use client"

import { useState } from "react"
import { BottomNav } from "@/components/bottom-nav"
import { ArrowLeft, Check, Palette, ChevronRight } from "lucide-react"
import Link from "next/link"

type ThemeType = "dark" | "light"
type IconStyle = "red" | "delcut" | "ouline" | "rouncle"

export default function CustomizationPage() {
  const [themeMode, setThemeMode] = useState<ThemeType>("dark")
  const [lightSelected, setLightSelected] = useState(false)
  const [selectedIcon, setSelectedIcon] = useState<IconStyle>("red")
  const [language, setLanguage] = useState("English")

  const iconStyles: { id: IconStyle; label: string; icon: string }[] = [
    { id: "red", label: "Red", icon: "●" },
    { id: "delcut", label: "Delcut", icon: "◯" },
    { id: "ouline", label: "Ouline", icon: "⊞" },
    { id: "rouncle", label: "Rouncle", icon: "◉" },
  ]

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-white pb-28">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-[#2D2D2D]">
        <Link href="/assistant">
          <ArrowLeft size={24} className="text-white cursor-pointer active:scale-90 transition-transform" />
        </Link>
        <h1 className="text-2xl font-bold">Customization</h1>
      </div>

      {/* Theme toggle */}
      <div className="px-4 mt-6">
        <div className="flex gap-2">
          <button
            onClick={() => {
              setThemeMode("dark")
              setLightSelected(false)
            }}
            className={`flex-1 py-2 rounded-full font-semibold text-sm transition-all active:scale-95 ${
              !lightSelected ? "bg-[#161616] text-white border-2 border-[#3b82f6]" : "bg-[#161616] text-[#9CA3AF]"
            }`}
          >
            Dark
          </button>
          <button
            onClick={() => {
              setLightSelected(true)
              setThemeMode("light")
            }}
            className={`flex-1 py-2 rounded-full font-semibold text-sm transition-all active:scale-95 ${
              lightSelected ? "bg-white text-black border-2 border-[#3b82f6]" : "bg-[#161616] text-[#9CA3AF]"
            }`}
          >
            Light
          </button>
        </div>
      </div>

      {/* Theme section */}
      <div className="px-4 mt-6">
        <p className="text-[#9CA3AF] text-sm mb-3">Theme</p>
        <div className="bg-[#181818] rounded-[20px] p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Palette size={20} className="text-white" />
            <p className="text-white font-semibold text-sm">Dark</p>
          </div>
          <Check size={20} className="text-[#3b82f6]" />
        </div>
      </div>

      {/* Icons section */}
      <div className="px-4 mt-6">
        <p className="text-[#9CA3AF] text-sm mb-3">Icons</p>
        <div className="grid grid-cols-2 gap-3">
          {iconStyles.map((style) => (
            <button
              key={style.id}
              onClick={() => setSelectedIcon(style.id)}
              className={`py-6 rounded-[20px] flex flex-col items-center justify-center transition-all active:scale-95 ${
                selectedIcon === style.id
                  ? "bg-[#2D2D2D] border-2 border-[#3b82f6]"
                  : "bg-[#181818] border border-[#2D2D2D]"
              }`}
            >
              <span className={`text-3xl mb-2 ${style.id === "red" ? "text-[#3b82f6]" : "text-[#6B7280]"}`}>
                {style.icon}
              </span>
              <span className="text-[#9CA3AF] text-xs font-medium">{style.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Language section */}
      <div className="px-4 mt-6">
        <p className="text-[#9CA3AF] text-sm mb-3">Language</p>
        <button
          onClick={() => alert("Language selector")}
          className="w-full bg-[#181818] rounded-[20px] p-4 flex items-center justify-between cursor-pointer hover:bg-[#1F1F1F] active:bg-[#2D2D2D] transition-colors"
        >
          <p className="text-white font-semibold text-sm">Language</p>
          <div className="flex items-center gap-2">
            <span className="text-[#9CA3AF] text-sm">{language}</span>
            <ChevronRight size={20} className="text-[#6B7280]" />
          </div>
        </button>
      </div>

      <BottomNav />
    </div>
  )
}
