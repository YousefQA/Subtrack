"use client"

import { useState } from "react"
import { BotIcon } from "@/components/icons"
import { BottomNav } from "@/components/bottom-nav"

export default function AIAssistancePage() {
  const [toastVisible, setToastVisible] = useState(false)

  const handleNotifyClick = () => {
    setToastVisible(true)
    setTimeout(() => setToastVisible(false), 3000)
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] pb-24">
      {/* Header */}
      <div className="px-6 py-6 border-b border-[#2D2D2D]">
        <h1 className="text-2xl font-bold text-[#F5F5F7]">AI Assistance</h1>
      </div>

      {/* Content - centered with icon and text */}
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] px-6">
        {/* Blue Bot Icon */}
        <BotIcon className="w-20 h-20 text-[#3b82f6] mb-8" />

        {/* Headline */}
        <h2 className="text-3xl font-bold text-[#F5F5F7] mb-4 text-balance">Work in Progress</h2>

        {/* Subheadline */}
        <p className="text-lg text-[#F5F5F7] mb-4 max-w-sm text-balance">
          AI Assistance — the future of subscriptions and reminders for the users.
        </p>

        {/* Muted subtitle */}
        <p className="text-[#9CA3AF] mb-8 max-w-sm text-balance text-sm">
          Coming soon: Smart deal suggestions, personalized alerts, and predictive renewal tracking.
        </p>

        {/* Notify Button */}
        <button
          onClick={handleNotifyClick}
          className="px-6 py-3 bg-[#3b82f6] text-white rounded-[20px] font-semibold active:scale-95 transition-transform"
        >
          Notify me when ready
        </button>
      </div>

      {/* Toast Notification */}
      {toastVisible && (
        <div className="fixed bottom-32 left-1/2 transform -translate-x-1/2 bg-[#3b82f6] text-white px-6 py-3 rounded-[12px] font-semibold animate-fade-in">
          Feature coming soon!
        </div>
      )}

      <BottomNav />
    </div>
  )
}
