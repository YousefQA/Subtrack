export interface Subscription {
  id: string
  name: string
  startedAt: Date
  endsAt: Date
}

export const mockSubscriptions: Subscription[] = [
  {
    id: "1",
    name: "Apple+",
    startedAt: new Date("2025-09-15"),
    endsAt: new Date("2025-12-15"),
  },
  {
    id: "2",
    name: "Spotify Premium",
    startedAt: new Date("2025-10-01"),
    endsAt: new Date("2025-11-30"),
  },
  {
    id: "3",
    name: "Netflix",
    startedAt: new Date("2025-08-10"),
    endsAt: new Date("2025-12-10"),
  },
  {
    id: "4",
    name: "Disney+",
    startedAt: new Date("2025-07-20"),
    endsAt: new Date("2026-01-20"),
  },
]

export const subscriptions = mockSubscriptions

export interface Notification {
  id: string
  type: "upcoming" | "overdue" | "read"
  title: string
  subtitle: string
  subscriptionId: string
  read: boolean
  snoozedUntil?: Date
}

export const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "upcoming",
    title: "Spotify Premium renews soon",
    subtitle: "Renews in 2 days",
    subscriptionId: "2",
    read: false,
  },
  {
    id: "2",
    type: "upcoming",
    title: "Apple+ renewal reminder",
    subtitle: "Renews in 30 days",
    subscriptionId: "1",
    read: false,
  },
  {
    id: "3",
    type: "overdue",
    title: "Netflix payment overdue",
    subtitle: "Payment failed yesterday",
    subscriptionId: "3",
    read: false,
  },
  {
    id: "4",
    type: "read",
    title: "Disney+ trial ending",
    subtitle: "Ends in 60 days",
    subscriptionId: "4",
    read: true,
  },
]
