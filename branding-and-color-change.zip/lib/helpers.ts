import type { Subscription } from "./mock-data"

export function getDaysRemaining(endsAt: Date): number {
  const now = new Date()
  const diffTime = endsAt.getTime() - now.getTime()
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  return Math.max(0, diffDays)
}

export function getActiveDuration(startedAt: Date): number {
  const now = new Date()
  const diffTime = now.getTime() - startedAt.getTime()
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))
  return diffDays
}

export function getNextEndingSubscription(subs: Subscription[]): Subscription | null {
  const active = subs.filter((s) => getDaysRemaining(s.endsAt) > 0)
  if (active.length === 0) return null
  return active.reduce((prev, curr) => {
    const prevDays = getDaysRemaining(prev.endsAt)
    const currDays = getDaysRemaining(curr.endsAt)
    return currDays < prevDays ? curr : prev
  })
}

export function getAverageMonthlySpend(subs: Subscription[]): number {
  if (subs.length === 0) return 0
  const total = subs.reduce((sum, s) => sum + (s.monthlyPrice || 0), 0)
  return total / subs.length
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
}
