export interface Subscription {
  id: string
  name: string
  startDate: Date
  endDate: Date
  price?: number
}

export interface Settings {
  theme: "dark" | "light"
  billingReminders: boolean
  trialAlerts: boolean
  currency: "USD" | "EUR" | "AED"
}
