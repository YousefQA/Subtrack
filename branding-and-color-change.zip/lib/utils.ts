import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function calculateDaysActive(startDate: Date): number {
  const now = new Date()
  const diffTime = Math.abs(now.getTime() - startDate.getTime())
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
}

export function calculateDaysRemaining(endDate: Date): number {
  const now = new Date()
  const diffTime = endDate.getTime() - now.getTime()
  return Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)))
}

export function formatCurrency(amount: number, currency = "USD"): string {
  const symbols: Record<string, string> = {
    USD: "$",
    EUR: "€",
    AED: "د.إ",
  }
  return `${symbols[currency] || currency} ${amount.toFixed(2)}`
}

// Subscription utility functions
