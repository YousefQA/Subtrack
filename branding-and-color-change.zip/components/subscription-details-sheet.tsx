"use client"

import { XIcon } from "@/components/icons"
import { getActiveDuration, getDaysRemaining } from "@/lib/helpers"
import type { Subscription } from "@/lib/mock-data"

interface SubscriptionDetailsSheetProps {
  isOpen: boolean
  subscription: Subscription | null
  onClose: () => void
}

export function SubscriptionDetailsSheet({ isOpen, subscription, onClose }: SubscriptionDetailsSheetProps) {
  if (!isOpen || !subscription) return null

  const daysActive = getActiveDuration(subscription.startedAt)
  const daysRemaining = getDaysRemaining(subscription.endsAt)

  return (
    <div className="fixed inset-0 bg-black/80 flex items-end z-50">
      <div className="w-full bg-[#121212] rounded-t-[24px] p-6 pb-8 max-w-sm mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-[#F5F5F7]">{subscription.name}</h2>
          <button onClick={onClose} className="p-1">
            <XIcon className="w-6 h-6 text-[#9CA3AF]" />
          </button>
        </div>

        <div className="space-y-3">
          <div className="bg-[#181818] rounded-[20px] p-4">
            <p className="text-[#9CA3AF] text-xs mb-1">Active for</p>
            <p className="text-[#F5F5F7] text-lg font-semibold">{daysActive} days</p>
          </div>

          <div className="bg-[#181818] rounded-[20px] p-4">
            <p className="text-[#9CA3AF] text-xs mb-1">Started</p>
            <p className="text-[#F5F5F7] text-sm">{subscription.startedAt.toLocaleDateString()}</p>
          </div>

          <div className="bg-[#181818] rounded-[20px] p-4">
            <p className="text-[#9CA3AF] text-xs mb-1">Ends</p>
            <p className="text-[#F5F5F7] text-sm">{subscription.endsAt.toLocaleDateString()}</p>
          </div>

          <div className="bg-[#181818] rounded-[20px] p-4">
            <p className="text-[#9CA3AF] text-xs mb-1">Days remaining</p>
            <p className={`text-lg font-semibold ${daysRemaining <= 3 ? "text-[#3b82f6]" : "text-[#F5F5F7]"}`}>
              {daysRemaining} days
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 bg-[#161616] text-[#F5F5F7] rounded-[12px] font-semibold mt-6"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  )
}
