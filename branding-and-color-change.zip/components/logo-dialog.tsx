"use client"

import { SubTrackLogo } from "@/components/subtrack-logo"

interface LogoDialogProps {
  isOpen: boolean
  onClose: () => void
}

export function LogoDialog({ isOpen, onClose }: LogoDialogProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 px-4">
      <div className="bg-[#121212] rounded-[24px] p-8 max-w-sm w-full flex flex-col items-center gap-6">
        <h2 className="text-xl font-bold text-[#F5F5F7]">SubTrack Logo</h2>
        <SubTrackLogo size={120} />
        <button onClick={onClose} className="w-full py-3 bg-[#3b82f6] text-white rounded-[12px] font-semibold">
          Close
        </button>
      </div>
    </div>
  )
}
