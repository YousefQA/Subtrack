"use client"

import Link from "next/link"
import { X } from "lucide-react"

interface MenuSheetProps {
  isOpen: boolean
  onClose: () => void
}

export function MenuSheet({ isOpen, onClose }: MenuSheetProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 flex items-end z-50">
      <div className="w-full bg-[#121212] rounded-t-[24px] p-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white">Menu</h2>
          <button onClick={onClose} className="p-1">
            <X size={24} className="text-[#9CA3AF]" />
          </button>
        </div>

        <div className="space-y-3">
          <button className="w-full py-3 bg-[#181818] text-white rounded-lg font-semibold text-left px-4">
            About SubTrack
          </button>
          <Link href="/customization" onClick={onClose}>
            <button className="w-full py-3 bg-[#181818] text-white rounded-lg font-semibold text-left px-4">
              Settings
            </button>
          </Link>
        </div>
      </div>
    </div>
  )
}
