"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { HomeIcon, ShoppingCartIcon, BotIcon, BellIcon, SettingsIcon } from "@/components/icons"

export function BottomNav() {
  const pathname = usePathname()
  const { isAuthenticated } = useAuth()

  // Don't show on auth pages
  if (!isAuthenticated || pathname === "/login" || pathname === "/signup") {
    return null
  }

  const isActive = (path: string) => pathname === path

  const tabs = [
    { href: "/", icon: HomeIcon, label: "Home" },
    { href: "/subscriptions", icon: ShoppingCartIcon, label: "Subscriptions" },
    { href: "/ai-assistance", icon: BotIcon, label: "AI" },
    { href: "/notifications", icon: BellIcon, label: "Notifications" },
    { href: "/settings", icon: SettingsIcon, label: "Settings" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-sm mx-auto h-24 bg-[#0B0B0B] border-t border-[#2D2D2D] flex items-center justify-around px-4">
      {tabs.map((tab) => {
        const Icon = tab.icon
        const active = isActive(tab.href)
        return (
          <Link key={tab.href} href={tab.href} className="flex flex-col items-center justify-center gap-1 flex-1">
            <Icon className={`w-6 h-6 ${active ? "text-[#3b82f6]" : "text-[#6B7280]"}`} />
            <span className={`text-xs font-medium ${active ? "text-[#3b82f6]" : "text-[#6B7280]"}`}>{tab.label}</span>
          </Link>
        )
      })}
    </nav>
  )
}
