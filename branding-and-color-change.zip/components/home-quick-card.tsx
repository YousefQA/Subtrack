"use client"

import Link from "next/link"
import { ChevronRightIcon } from "@/components/icons"
import type { ReactNode } from "react"

interface HomeQuickCardProps {
  href: string
  icon: ReactNode
  title: string
  fullWidth?: boolean
}

export function HomeQuickCard({ href, icon, title, fullWidth = false }: HomeQuickCardProps) {
  return (
    <Link href={href}>
      <button
        className={`w-full bg-[#181818] rounded-[20px] p-6 flex items-center justify-between gap-4 active:scale-95 transition-transform ${
          fullWidth ? "" : "h-40"
        }`}
      >
        <div className="flex items-center gap-4">
          <div className="text-[#3b82f6] w-8 h-8">{icon}</div>
          <h2 className="text-lg font-semibold text-[#F5F5F7]">{title}</h2>
        </div>
        <ChevronRightIcon className="w-6 h-6 text-[#6B7280]" />
      </button>
    </Link>
  )
}
