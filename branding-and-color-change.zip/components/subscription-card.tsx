"use client"

import { ChevronRightIcon } from "@/components/icons"
import { getActiveDuration, getDaysRemaining } from "@/lib/helpers"
import type { Subscription } from "@/lib/mock-data"

interface SubscriptionCardProps {
  subscription: Subscription
  onClick: () => void
}

export function SubscriptionCard({ subscription, onClick }: SubscriptionCardProps) {
  const daysActive = getActiveDuration(subscription.startedAt)
  const daysRemaining = getDaysRemaining(subscription.endsAt)

  return (
    <button
      onClick={onClick}
      className="w-full bg-[#181818] rounded-[20px] p-4 flex items-center justify-between hover:bg-[#1F1F1F] transition-colors active:scale-95"
    >
      <div className="text-left">
        <p className="text-[#F5F5F7] font-semibold">{subscription.name}</p>
        <p className="text-[#9CA3AF] text-sm mt-1">Active for {daysActive} days</p>
        <p className={`text-sm mt-1 ${daysRemaining <= 3 ? "text-[#3b82f6]" : "text-[#9CA3AF]"}`}>
          Ends in {daysRemaining} days
        </p>
      </div>
      <ChevronRightIcon className="w-6 h-6 text-[#6B7280]" />
    </button>
  )
}
