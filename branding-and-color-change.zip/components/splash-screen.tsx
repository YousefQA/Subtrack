"use client"

import { useEffect, useState } from "react"
import { SubTrackLogo } from "@/components/subtrack-logo"

export function SplashScreen() {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (!isVisible) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B0B0B]">
      <div className="flex flex-col items-center gap-4">
        <SubTrackLogo size={80} className="animate-pulse" />
        <p className="text-[#F5F5F7] font-semibold text-lg">SubTrack</p>
      </div>
    </div>
  )
}
