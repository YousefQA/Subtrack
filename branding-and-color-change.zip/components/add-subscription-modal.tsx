"use client"

import { useState } from "react"
import { XIcon } from "@/components/icons"

interface AddSubscriptionModalProps {
  isOpen: boolean
  onClose: () => void
  onAdd: (name: string, startDate: string, endDate: string) => void
}

export function AddSubscriptionModal({ isOpen, onClose, onAdd }: AddSubscriptionModalProps) {
  const [name, setName] = useState("")
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")

  const handleSave = () => {
    if (name && startDate && endDate) {
      onAdd(name, startDate, endDate)
      setName("")
      setStartDate("")
      setEndDate("")
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 flex items-end z-50">
      <div className="w-full bg-[#121212] rounded-t-[24px] p-6 pb-8 max-w-sm mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-[#F5F5F7]">Add subscription</h2>
          <button onClick={onClose} className="p-1">
            <XIcon className="w-6 h-6 text-[#9CA3AF]" />
          </button>
        </div>

        <div className="space-y-4">
          <input
            type="text"
            placeholder="Subscription name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-[#181818] rounded-[12px] px-4 py-3 text-[#F5F5F7] placeholder-[#6B7280] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
          />
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full bg-[#181818] rounded-[12px] px-4 py-3 text-[#F5F5F7] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
          />
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full bg-[#181818] rounded-[12px] px-4 py-3 text-[#F5F5F7] border border-[#2D2D2D] focus:outline-none focus:border-[#3b82f6]"
          />

          <div className="flex gap-3 pt-4">
            <button onClick={onClose} className="flex-1 py-3 bg-[#161616] text-[#F5F5F7] rounded-[12px] font-semibold">
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="flex-1 py-3 bg-[#3b82f6] text-white rounded-[12px] font-semibold active:scale-95 transition-transform"
            >
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
