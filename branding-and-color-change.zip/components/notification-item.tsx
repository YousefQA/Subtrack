"use client"

import { ClockIcon, AlertCircleIcon } from "@/components/icons"
import type { Notification } from "@/lib/mock-data"

interface NotificationItemProps {
  notification: Notification
  subscriptionName: string
  onMarkRead: () => void
  onSnooze: () => void
}

export function NotificationItem({ notification, subscriptionName, onMarkRead, onSnooze }: NotificationItemProps) {
  const getIcon = () => {
    if (notification.type === "overdue") {
      return <AlertCircleIcon className="w-5 h-5 text-[#3b82f6]" />
    }
    return <ClockIcon className="w-5 h-5 text-[#9CA3AF]" />
  }

  return (
    <div className="bg-[#181818] rounded-[16px] p-4 space-y-3">
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 mt-1">{getIcon()}</div>
        <div className="flex-1">
          <p className={`font-semibold ${!notification.read ? "text-[#F5F5F7]" : "text-[#9CA3AF]"}`}>
            {subscriptionName}
          </p>
          <p className="text-[#F5F5F7] text-sm mt-1">{notification.title}</p>
          <p className="text-[#9CA3AF] text-sm">{notification.subtitle}</p>
        </div>
      </div>
      <div className="flex gap-2">
        <button
          onClick={onMarkRead}
          className="flex-1 px-3 py-2 bg-[#0B0B0B] text-[#9CA3AF] rounded-lg text-sm font-medium active:scale-95 transition-transform"
        >
          {notification.read ? "Mark unread" : "Mark read"}
        </button>
        <button
          onClick={onSnooze}
          className="flex-1 px-3 py-2 bg-[#0B0B0B] text-[#9CA3AF] rounded-lg text-sm font-medium active:scale-95 transition-transform"
        >
          Snooze
        </button>
      </div>
    </div>
  )
}
