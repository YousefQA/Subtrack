"use client"

import { useEffect, useRef } from "react"

interface SubTrackLogoProps {
  size?: number
  className?: string
}

export function SubTrackLogo({ size = 64, className = "" }: SubTrackLogoProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const imgSrc =
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-e2V1ujE2ZCdBvLW0X9ByYSW8Luyby6.png"

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => {
      canvas.width = img.naturalWidth
      canvas.height = img.naturalHeight
      ctx.drawImage(img, 0, 0)

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
      const data = imageData.data

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i]
        const g = data[i + 1]
        const b = data[i + 2]
        // If the pixel is near-white (all channels > 220), make it transparent
        if (r > 220 && g > 220 && b > 220) {
          data[i + 3] = 0
        }
      }

      ctx.putImageData(imageData, 0, 0)
    }
    img.src = imgSrc
  }, [])

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className={className}
      style={{ width: size, height: size }}
      aria-label="SubTrack logo"
    />
  )
}
